
if(window.navigator.language=="zh_CN"||"zh_TW"){
	document.getElementById("notifi-zh").style.display="block";
	}
else{
	document.getElementById("notifi-en").style.display="block"}