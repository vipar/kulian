import random
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from flask import Response

import config
import flask

from script.chrome import asyncBkex, syncBkex
from utils import ThreadManage
from utils.LogUtil import getLogger

logging = getLogger('brush')
api = flask.Flask(__name__)

@api.route('/<reg>.pac', methods=['get'])
def pac(reg='tr'):
    httpProxy = config.chromeProxyList[reg]
    pac = """function FindProxyForURL(url, host) {
          if (shExpMatch(url, "*alicdn.com/*") ||
              shExpMatch(url, "*bkex.com/static/*") ||
              shExpMatch(url, "*bkex.com/api/*") ||
              shExpMatch(url, "*aliyuncs.com/pc/*") ||
              shExpMatch(url, "*assets.giocdn.com/2.1/gio.js") ||
              shExpMatch(url, "*www.google-analytics.com/analytics.js") ||
              shExpMatch(url, "*2022.ip138.com/index.html*")) {
            return "DIRECT"
          }
          return "PROXY %s"
    }""" % httpProxy
    print(httpProxy)
    r = Response(response=pac, status=200, mimetype="application/x-ns-proxy-autoconfig")
    r.headers["Content-Type"] = "application/x-ns-proxy-autoconfig; charset=utf-8"
    return r


def brush():
    threadPool = ThreadPoolExecutor(max_workers=config.threadNum)

    while True:
            if ThreadManage.checkThreadNum(config.threadNum):
                continue
            try:
                proxy = random.choice(list(config.chromeProxyList.keys()))
                logging.info("浏览器请求:代理:{}".format(proxy))
                ThreadManage.addThreadNum()
                threadPool.submit(asyncBkex.main, proxy)
                time.sleep(2)
            except Exception as e:
                ThreadManage.addThreadNum()
                logging.error('刷量错误,error:{}'.format(e))

if __name__ == '__main__':
    shutil.rmtree("C:\\chromeUserCache\\", ignore_errors= True)
    time.sleep(5)
    pool = ThreadPoolExecutor(max_workers=1)
    pool.submit(brush)
    api.run(port=8888, host='0.0.0.0')

