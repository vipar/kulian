from threading import Lock

mutex = Lock()
# 执行中的线程数
runThreadNum = 0


def checkThreadNum(num):
    global runThreadNum
    mutex.acquire()
    n = num == runThreadNum
    mutex.release()
    return n

# 增加次数
def addThreadNum():
    global runThreadNum
    mutex.acquire()
    runThreadNum += 1
    mutex.release()

# 增加次数
def subThreadNum():
    global runThreadNum
    mutex.acquire()
    runThreadNum -= 1
    mutex.release()