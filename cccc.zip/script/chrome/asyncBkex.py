import asyncio
import os
import random
import re
import shutil

from playwright.async_api import async_playwright

import config
from utils import ThreadManage

js1 = """
    Object.defineProperties(navigator, {webdriver:{get:()=>undefined}});
    """
js = """
    var index =document.createElement("a");
    index.href = "https://www.bkex.com";
    index.text = "BKEX首页";
    index.classList.add("brush");
    document.body.insertBefore(index, document.body.firstElementChild)
    pairs = ['BTC_USDT','ETH_USDT','BNB_USDT','GMT_USDT','TRX_USDT','BKK_USDT']
    pairs.forEach(function(s) {
        var trade =document.createElement("a");
        trade.href = "https://www.bkex.com/trade/" + s;
        trade.text = s + "交易";
        trade.classList.add("brush");
        document.body.insertBefore(trade, document.body.firstElementChild)
    });
"""
async def handle_popup(popup):
    await popup.wait_for_load_state()
    print(await popup.title())

async def run(proxy, ua, width, height, extensionPath, userDataDir):
    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(channel="chrome"
                                                                      , user_data_dir= userDataDir
                                                                      , ignore_default_args=["--enable-automation"]
                                                                      , args=[f"--proxy-pac-url=http://127.0.0.1:8888/{proxy}.pac"
                                                                            , f"--disable-extensions-except={extensionPath}"
                                                                            , f"--load-extension={extensionPath}"
                                                                              ]
                                                                      , headless=False
                                                                      , locale="en-US"
                                                                      , user_agent=ua
                                                                      , viewport={"width": width, "height": height}
                                                                      , screen={"width": width, "height": height})
        try:
            page = await context.new_page()
            page.set_default_timeout(120000)
            page.set_default_navigation_timeout(120000)
            await page.add_init_script(js1)
            if(extensionPath.find('hoklmmgfnpapgjgcpechhaamimifchmp') > -1):
                # sw插件设置后台默认查询
                await page.goto("chrome-extension://hoklmmgfnpapgjgcpechhaamimifchmp/options/options.html", wait_until="networkidle")
                await page.click(selector='#autoIcon')
                await page.wait_for_timeout(1000)
                await page.click(selector='#openInBg')
                await page.wait_for_timeout(1000)
            try:
                await page.goto("https://www.google.com/search?q=bkex")
                await page.bring_to_front()
                await page.wait_for_selector(selector='a[href*="www.bkex.com"]')
                await page.click(selector='a[href*="www.bkex.com"]')
            except Exception as e:
                await page.goto("https://www.bkex.com")
                print(e)
            await page.wait_for_load_state(state="networkidle")
            for i in range(3):
                await page.evaluate(js)
                await page.wait_for_timeout(5000)
                await page.click(selector='.brush:nth-child({})'.format(str(random.randint(1, 7))))
                await page.wait_for_timeout(30000)
            await page.close()
            await context.close()
            shutil.rmtree(userDataDir, ignore_errors= True)
            ThreadManage.subThreadNum()
        except Exception as e:
            print(e)
            await context.close()
            shutil.rmtree(userDataDir, ignore_errors= True)
            ThreadManage.subThreadNum()

randomStr = '0123456789abcdefghijklmnopqrstuvwxyz'
extensionPathList = ['hoklmmgfnpapgjgcpechhaamimifchmp\\5.6.5_0'
    ,'cmedhionkhpnakcndndgjdbohmhepckk\\5.2_0'
    ,'gighmmpiobklfepjocnamgkkbiglidom\\5.0.4_0'
    ,'jlgkpaicikihijadgifklkbpdajbkhjo\\5.0.2_0']
def main(proxy):
    userAgent = random.choice(config.userAgentList)
    view = random.choice(config.viewportList)
    extensionId = str(random.choice(extensionPathList))
    if(random.randint(0,1) == 0):
        # 加大官方插件加载概率
        extensionId = extensionPathList[0]
    extensionPath = 'C:\\crx\\' + extensionId
    userDataDir = 'C:\\chromeUserCache\\{}'.format(''.join(random.sample(randomStr, 10)))
    extensionPath2 = userDataDir + '\\' + extensionId
    shutil.copytree(extensionPath, extensionPath2)
    asyncio.run(run(proxy, userAgent, int(view.split("x")[0]), int(view.split("x")[1]), extensionPath2, userDataDir))