import random
import re
import time

from playwright.sync_api import sync_playwright

import config
from utils import ThreadManage

js = """
    Object.defineProperties(navigator, {webdriver:{get:()=>undefined}});
    var index =document.createElement("a");
    index.href = "https://www.bkex.com";
    index.text = "BKEX首页";
    index.classList.add("brush");
    document.body.insertBefore(index, document.body.firstElementChild)
    pairs = ['BTC_USDT','ETH_USDT','BNB_USDT','GMT_USDT','TRX_USDT','BKK_USDT']
    pairs.forEach(function(s) {
        var trade =document.createElement("a");
        trade.href = "https://www.bkex.com/trade/" + s;
        trade.text = s + "交易";
        trade.classList.add("brush");
        document.body.insertBefore(trade, document.body.firstElementChild)
    });
"""

def run(proxy):
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel="chrome",
                                                   headless=False)
        try:
            context = browser.new_context(locale="en-US")
            page = context.new_page()
            page.set_default_timeout(120000)
            page.set_default_navigation_timeout(120000)
            page.route(re.compile(r"(\.css)|(\.gif)|(socket\.io)|(\.png)|(\.jpg)|(/api/(?!q/trade/quotation))"),
                         lambda route: route.abort())
            page.goto("https://www.google.com/search?q=bkex")
            page.wait_for_selector(selector='a[href*="www.bkex.com"]')
            page.click(selector='a[href*="www.bkex.com"]')
            page.wait_for_timeout(10000)
            for i in range(3):
                page.evaluate(js)
                page.wait_for_timeout(10000)
                page.click(selector='.brush:nth-child({})'.format(str(random.randint(1, 7))))
                page.wait_for_timeout(30000)
            page.close()
            context.close()
            browser.close()
        except Exception as e:
            print(e)
            browser.close()