import asyncio
import random
import re

from playwright.async_api import async_playwright

import config
from utils import ThreadManage

js1 = """
    Object.defineProperties(navigator, {webdriver:{get:()=>undefined}});
    """
js = """
    var index =document.createElement("a");
    index.href = "https://www.bkex.com";
    index.text = "BKEX首页";
    index.classList.add("brush");
    document.body.insertBefore(index, document.body.firstElementChild)
    pairs = ['BTC_USDT','ETH_USDT','BNB_USDT','GMT_USDT','TRX_USDT','BKK_USDT']
    pairs.forEach(function(s) {
        var trade =document.createElement("a");
        trade.href = "https://www.bkex.com/trade/" + s;
        trade.text = s + "交易";
        trade.classList.add("brush");
        document.body.insertBefore(trade, document.body.firstElementChild)
    });
"""

async def run(proxy, ua, width, height):
    async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(channel="chrome", args=["--proxy-pac-url=http://127.0.0.1:8888/{}.pac".format(proxy)],
                                                 headless=False)
            try:
                context = await browser.new_context(locale="en-US", user_agent=ua, viewport={"width": width, "height": height}, screen={"width": width, "height": height})
                page = await browser.new_page()
                page.set_default_timeout(120000)
                page.set_default_navigation_timeout(120000)
                await page.add_init_script(js1)
                await page.route(re.compile(r"(\.css)|(\.gif)|(socket\.io)|(\.png)|(\.jpg)|(/api/(?!q/trade/quotation))"), lambda route: route.abort("failed"))
                try:
                    await page.goto("https://www.google.com/search?q=bkex")
                    await page.wait_for_selector(selector='a[href*="www.bkex.com"]')
                    await page.click(selector='a[href*="www.bkex.com"]')
                except Exception as e:
                    await page.goto("https://www.bkex.com")
                    print(e)
                await page.wait_for_load_state(state="networkidle")
                for i in range(3):
                    await page.evaluate(js)
                    await page.wait_for_timeout(5000)
                    await page.click(selector='.brush:nth-child({})'.format(str(random.randint(1, 7))))
                    await page.wait_for_timeout(30000)
                await page.close()
                await context.close()
                await browser.close()
                ThreadManage.subThreadNum()
            except Exception as e:
                print(e)
                await browser.close()
                ThreadManage.subThreadNum()

def main(proxy):
    userAgent = random.choice(config.userAgentList)
    view = random.choice(config.viewportList)
    asyncio.run(run(proxy, userAgent, int(view.split("x")[0]), int(view.split("x")[1])))
