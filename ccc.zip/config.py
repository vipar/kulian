# 跳出率线程数
from threading import Lock

bounceRateNum = 0
# 访问时长线程数
timeTaskNum = 10
# 每个容器的总线程数
threadNum = bounceRateNum + timeTaskNum
# 日志存放目录
logPath = ''
# 谷歌代理
chromeProxyList = {'tr': '18.141.235.130:10778',
                'ru':'18.141.235.130:10899',
                'vn':'18.141.235.130:10911',
                'kr':'18.141.235.130:10624'}
# 分辨率
viewportList = ['1024x768','1366x768','1920x1080','1440x900']
# 钉钉报警地址
messageUrl = 'https://oapi.dingtalk.com/robot/send?access_token=31783acee83ccbdbf464f9724969269ba270d2f0b71b03bcce02aad7ea31c4e6'
#浏览器标识列表
userAgentList = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36"]
