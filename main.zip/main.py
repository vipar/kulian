import random
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from flask import Response

import config
import flask

from script.chrome import asyncBkex, syncBkex
from utils import ThreadManage
from utils.LogUtil import getLogger

logging = getLogger('brush')
api = flask.Flask(__name__)

@api.route('/<reg>.pac', methods=['get'])
def pac(reg='tr'):
    httpProxy = config.chromeProxyList[reg]
    pac = """function FindProxyForURL(url, host) {
          if (shExpMatch(url, "*google-analytics.com/*") ||
              shExpMatch(url, "*api.growingio.com*") ||
              shExpMatch(url, "*tags.growingio.com*") ||
              shExpMatch(url, "*2022.ip138.com/index.html*")) {
            return "PROXY %s"
          }
          return "DIRECT"
    }""" % httpProxy
    print(httpProxy)
    r = Response(response=pac, status=200, mimetype="application/x-ns-proxy-autoconfig")
    r.headers["Content-Type"] = "application/x-ns-proxy-autoconfig; charset=utf-8"
    return r


def brush():
    threadPool = ThreadPoolExecutor(max_workers=config.threadNum)

    while True:
            if ThreadManage.checkThreadNum(config.threadNum):
                continue
            try:
                proxy = random.choice(list(config.chromeProxyList.keys()))
                logging.info("浏览器请求:代理:{}".format(proxy))
                threadPool.submit(asyncBkex.main, proxy)
                ThreadManage.addThreadNum()
                time.sleep(2)
            except Exception as e:
                ThreadManage.addThreadNum()
                logging.error('刷量错误,error:{}'.format(e))

if __name__ == '__main__':
    pool = ThreadPoolExecutor(max_workers=1)
    pool.submit(brush)
    api.run(port=8888, host='0.0.0.0')

