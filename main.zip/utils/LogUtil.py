import logging
from datetime import datetime

from config import logPath


def getLogger(name):
    logger = logging.getLogger(name)
    if len(logger.handlers) > 0:
        return logger
    # 写入文件
    filename = f'{datetime.now().date()}_{name}.log'
    fh = logging.FileHandler(logPath + filename, mode='a', encoding='utf-8')
    # 输出格式
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # 输出级别
    logger.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)

    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(fh)
    logger.addHandler(sh)
    return logger
